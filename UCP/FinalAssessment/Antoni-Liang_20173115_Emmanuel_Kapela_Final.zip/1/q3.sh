#!/bin/bash
grep -i 'am' name.txt | sort -n