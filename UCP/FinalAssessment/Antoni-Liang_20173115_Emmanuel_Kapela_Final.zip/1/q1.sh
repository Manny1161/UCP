#!/bin/bash
grep -v '[aeiou]$' name.txt