#!/bin/bash
grep -x '^[AB].\{0,4\}' name.txt