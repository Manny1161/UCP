#ifndef TABLE_H
#define TABLE_H
int neighbourCount(int **table, int i, int j, int row, int col);
#endif