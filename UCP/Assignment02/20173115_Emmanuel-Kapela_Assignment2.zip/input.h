#ifndef INPUT_H
#define INPUT_H
void input(char **map, int row_size, int col_size, int snake_len, char *snake, char *food, int player_row, int player_col, int food_row, int food_col, char *tail, int tail_row, int tail_col, char *snake_w, char *snake_s, char *snake_a, char *body_h, int body_row, int body_col, char *body_v);
void input1(char **map, int row_size, int col_size, int snake_len, char *snake, char *food, int player_row, int player_col, int food_row, int food_col, char *tail, int tail_row, int tail_col, char *snake_w, char *snake_s, char *snake_a, char *body_h, int body_row, int body_col, char *body_v);
#endif